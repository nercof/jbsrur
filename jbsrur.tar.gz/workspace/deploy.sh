#!/bin/bash
echo >&2 'error: missing required WORDPRESS_DB_PASSWORD environment variable'

