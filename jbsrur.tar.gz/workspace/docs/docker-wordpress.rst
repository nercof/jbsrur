Docker-wordpress
================

Se investigaron los siguientes sitios `SIT2`_, `SIT2`_, `SIT3`_:

.. _SIT1: https://www.sitepoint.com/how-to-manually-build-docker-containers-for-wordpress/
.. _SIT2: https://www.sitepoint.com/how-to-use-the-official-docker-wordpress-image/
.. _SIT3: https://github.com/brunocascio/docker-espanol


Imagenes con imagenes oficiales
-------------------------------

Para levantar wordpress en docker con las imagenes oficiales ejecutar:

1. Bajar imagen de wordpress y mysql
.. code:: bash
  marilynpi:~/workspace $ sudo docker pull wordpress
  marilynpi:~/workspace $ sudo docker pull mysql

  
2. Levantar contenedor con base de datos:
.. code:: bash
  marilynpi:~/workspace $ sudo docker run --name wordpressdb -e \
         MYSQL_ROOT_PASSWORD=password -e MYSQL_DATABASE: =wordpress -d mysql:5.7

.. note:: Variables de entorno:
    -e MYSQL_ROOT_PASSWORD: obligatoria. password del usuario root.
    -e MYSQL_DATABASE: opcional. crea una base de datos con ese nombre.
    -e MYSQL_USER -e MYSQL_PASSWORD: opcionales. se usan juntas para usar otro user que no sea root y su password.
    -e MYSQL_ALLOW_EMPTY_PASSWORD: opcional. si setea con 'yes' y el contenedor es creado con un usuario root
    y sin password o ''

En nuestro caso seria:
.. code:: bash    
  marilynpi:~/workspace $ sudo docker run --name jbsrurdb \ 
  -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=jbsrur -d mysql:5.7

3. Levantar el contenedor wordpress y linkearlo con el contenedor mysql
.. code:: bash
  marilynpi:~/workspace $ docker run --name some-wordpress --link some-mysql-container:mysql -d wordpress
  
.. note:: Variables de entorno:
    -e WORDPRESS_DB_PASSWORD: por defecto la variable de entorno MYSQL_ROOT_PASSWORD seteada en el container mysql linkeado
    -e WORDPRESS_DB_USER: por defecto 'root'
    -e WORDPRESS_DB_HOST: por defecto la IP y el puerto del container mysql linkeado.
    -e WORDPRESS_DB_NAME: nombre de la db. por defecto 'wordpress'.
    -e WORDPRESS_TABLE_PREFIX: prefix de las tablas de la bd, por defecto ''.
    (docker run -e WORDPRESS_DB_PASSWORD=root -d -p 127.0.0.2:8080:80 -v "$PWD/":/var/www/html --name jbsrur --link jbsrurdb:mysql wordpress)

Nuestras imagenes
-----------------
sudo docker run --name wpdb -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=wp -d mysql:5.7
sudo chmod -R 777 jbsrur
cd jbsrur
docker build -t wp-angular .
docker run -e WORDPRESS_DB_PASSWORD=root -d -p 127.0.0.2:8080:80 -v "$PWD"/wp-content:/var/www/html/wp-content -t -i --name wp-angular --link wpdb:mysql  wp-angular
docker ps
docker exec -i -t wp-angular /bin/bash
docker exec -i wpdb mysql -uroot -proot wp < db.sql




docker exec -i -t wp-angular1 /bin/bash -> abre una terminal
http://146.185.183.11:9000/wiki