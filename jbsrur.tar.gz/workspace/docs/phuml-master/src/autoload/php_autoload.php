<?php

return array( 
    'plPhpClass'                => 'classes/php/class.php',
    'plPhpFunction'             => 'classes/php/function.php',
    'plPhpInterface'            => 'classes/php/interface.php',
    'plPhpAttribute'            => 'classes/php/attribute.php',
    'plPhpFunctionParameter'    => 'classes/php/functionParameter.php',
);

?>
