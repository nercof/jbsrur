============
Useful Tools
============

PHPUml
======

Para generar diagramas de clases desde .php vamos a utilizar `PHPUml`_

.. code:: bash

 marilynpi:~/workspace/docs $ wget -c http://dasunhegoda.com/wp-content/uploads/2015/04/phuml-master.zip
 marilynpi:~/workspace/docs $ unzip phuml-master.zip
 ...
 marilynpi:~/workspace/docs $ cd phuml-master/src/app
 marilynpi:~/workspace/docs/phuml-master/src/app $ chmod +x phuml
 marilynpi:~/workspace/docs/phuml-master/src/app $ ./phuml 
  phUML Version 0.2 (Jakob Westhoff <jakob@php.net>)
  Usage: phuml [-h|-l] [OPTIONS] <DIRECTORY> <PROCESSOR> [PROCESSOR OPTIONS] ... <OUTFILE>
  
  Commands:
      -h      Display this help text
      -l      List all available processors
  
  Options: 
      -r      Scan given directorie recursively
  
  Example:
      phuml -r ./ -graphviz -createAssociations false -neato out.png
  
      This example will scan the current directory recursively for php files.
      Send them to the "dot" processor which will process them with the option
      "createAssociations" set to false. After that it will be send to the neato
      processor and saved to the file out.png

Listo ya tenemos la aplicación funcionando. Ahora para generar el diagrama solamente
tenemos que ejecutar el siguiente comando:

.. code:: bash

 marilynpi:~/workspace/docs/phuml-master/src/app $ ./phuml -r /home/ubuntu/workspace/wp-content/themes/wp-angular/includes -graphviz -createAssociations false -neato class.png
 phUML Version 0.2 (Jakob Westhoff <jakob@php.net>)
 [|] Running... (This may take some time)
 [|] Parsing class structure
 [|] Running 'Graphviz' processor
 [|] Running 'Neato' processor
 Fontconfig warning: ignoring C.UTF-8: not a valid language tag
 Warning: some nodes with margin (3.20,3.20) touch - falling back to straight line edges
 [|] Writing generated data to disk
 marilynpi:~/workspace/docs/phuml-master/src/app $ 

.. _PHPUml: https://github.com/jakobwesthoff/phuml

reStructuredText
================

Para generar documentation vamos a emplear `reStText`_

.. code:: bash

 marilynpi:~/workspace/docs $ apt-cache search docutils
 docutils-common - text processing system for reStructuredText - common data
 docutils-doc - text processing system for reStructuredText - documentation
 python-docutils - text processing system for reStructuredText (implemented in Python 2)
 python3-docutils - text processing system for reStructuredText (implemented in Python 3)
 marilynpi:~/workspace/docs $ sudo apt-get install python-docutils

Editor online para experimentar Online reStructuredText editor `edRst`_ y podemos consultar el siguiente post `restructuredtext-tool-support`_

.. _reStText: http://docutils.sourceforge.net/
.. _restructuredtext-tool-support: http://stackoverflow.com/questions/2746692/restructuredtext-tool-support
.. _edRst: http://rst.ninjs.org/

AngularJS
=========
API Reference: `APIAJS`_
Oficial Tutorial: `OTU`_
Servicios: `SER`_
Angular 1 Style Guide: `COD`_
Activar angularjs en Cloud9: `CL9`_

Para seguir con el tutorial `TUT`_ podemos activar un entorno en Cloud9 de la 
siguiente manera: 

1. Crar un workspace PHP vacío.
2. Desde la terminal eliminar los archivos generados, que no son útiles:

.. code:: bash 
 $ rm -rf * .c9

3. Clone Angular e instalar 

.. code:: bash 
 nercof:~/workspace $ git clone --depth=16 https://github.com/angular/angular-phonecat.git
 Cloning into 'angular-phonecat'...
 remote: Counting objects: 280, done.
 remote: Compressing objects: 100% (181/181), done.
 remote: Total 280 (delta 103), reused 263 (delta 97), pack-reused 0
 Receiving objects: 100% (280/280), 1.44 MiB | 0 bytes/s, done.
 Resolving deltas: 100% (103/103), done.
 Checking connectivity... done.
 nercof:~/workspace $ cd angular-phonecat
 nercof:~/workspace/angular-phonecat (master) $ npm install

.. _APIAJS: https://docs.angularjs.org/api/ng
.. _TUT: http://viralpatel.net/blogs/angularjs-service-factory-tutorial/
.. _OTU: https://docs.angularjs.org/tutorial
.. _SER: http://blog.jdriven.com/2013/03/how-to-create-singleton-angularjs-services-in-4-different-ways/
.. _COD: https://github.com/johnpapa/angular-styleguide/blob/master/a1/README.md
.. _CL9: https://community.c9.io/t/getting-started-with-angularjs/1729
.. _Cloud9: https://c9.io/?redirect=0
.. https://github.com/angular/angular.js/wiki/Understanding-Dependency-Injection

Unitest Angular
---------------

Vamos a emplear Jasmine 
http://jasmine.github.io/2.4/introduction.html


Ficheros
--------
header.php: Definir Aplicacion y Componentes 

.. code:: html
  
  <html <?php language_attributes();?> ng-app="APP">
  <script src="*.js"></script>
  <script src="*.component.js"></script>
  
index.php: Definir: <div ng-view></div>

Docker
======

http://blog.zot24.com/tips-tricks-docker/
https://getcarina.com/docs/tutorials/data-volume-containers/
https://getcarina.com/docs/tutorials/backup-restore-data/
https://www.sitepoint.com/how-to-use-the-official-docker-wordpress-image/
http://bitjudo.com/blog/2014/03/13/building-efficient-dockerfiles-node-dot-js/
https://github.com/npm/npm/issues/8836
http://www.clock.co.uk/blog/a-guide-on-how-to-cache-npm-install-with-docker
https://www.sitepoint.com/how-to-manually-build-docker-containers-for-wordpress/

Docker-import-mysql: `SOL0`_
-----------------------------

Para importar una Base de datos ya generada podemos usar `SOL1`_:
.. code:: bash 
 nercof:~/workspace $ docker exec -i db mysql -uroot -pexample <UNA_DB> < dump.sql
 nercof:~/workspace $ docker exec -i db mysql -uroot -pexample wordpress < dump.sql
 02:38:59 - nercof@nemosha {master} ~/Projects/jbsrur$ docker exec -i -t wp-angular /bin/bash
 02:38:59 - nercof@nemosha {master} ~/Projects/jbsrur$ docker exec -i wpdb mysql -uroot -proot wp < db.sql

.. _SOL1: http://depressiverobot.com/2015/02/19/mysql-dump-docker.html 
 
Tambien podemos probar el siguiente `SOL2`_:
.. code:: bash 
 # Create an executable script init_db.sh:
 #!/bin/bash
 /usr/bin/mysqld_safe &
 sleep 5
 mysql -u root -e "CREATE DATABASE mydb"
 mysql -u root mydb < /tmp/dump.sql
 
Add these lines to your Dockerfile:
.. code:: bash  
 ADD init_db.sh /tmp/init_db.sh
 RUN /tmp/init_db.sh

Solucion 4 `SOL4`_:

.. _SOL2: http://stackoverflow.com/questions/25920029/setting-up-mysql-and-importing-dump-within-dockerfile
.. _SOL0: http://www.luiselizondo.net/a-tutorial-on-how-to-use-mysql-with-docker/
.. _SOL3: http://www.nkode.io/
.. _SOL4: http://stackoverflow.com/questions/28127369/run-mysql-instance-in-docker-container

VER: 
https://hub.docker.com/r/dsifford/wordpress/
https://github.com/visiblevc/wordpress-starter
https://www.youtube.com/watch?v=2ZX3F-aFOxQ
https://docs.docker.com/opensource/project/test-and-docs/
http://blog.terranillius.com/post/docker_testing/

Dockerfile strategies for Git
-----------------------------

http://stackoverflow.com/questions/33682123/dockerfile-strategies-for-git
http://stackoverflow.com/questions/23391839/clone-private-git-repo-with-dockerfile

Dockerfile & ENV variables
--------------------------
http://staxmanade.com/2016/05/how-to-get-environment-variables-passed-through-docker-compose-to-the-containers/
https://support.aptible.com/topics/paas/how-to-access-environment-variables-inside-dockerfile/
https://support.aptible.com/topics/paas/how-to-access-environment-variables-inside-dockerfile/

Varios
------
https://github.com/zeroveride/Dockerfile-wordpress/blob/master/Dockerfile
https://github.com/signalfire/signalfire-wp-apache/blob/master/Dockerfile
https://github.com/GistLabs/docker-server-migration
https://visible.vc/engineering/docker-environment-for-wordpress/

.. code::bash
 docker ps -a | grep 'weeks ago' | awk '{print $1}' | xargs --no-run-if-empty docker rm
 https://platzi.com/blog/wordpress-en-docker/
 
http://freezeprosoftware.com/news/reactjs-vs-angularjs.aspx#.V4U4wDXhDiz
http://v2.wp-api.org/guide/plugins/
http://shprink.github.io/wp-api-angularjs/
http://mywiki.wooledge.org/BashFAQ/024
https://gist.github.com/kvzhuang/8233907

VER
https://github.com/angular-ui/ui-router/wiki
http://www.davecooper.org/angular-project-structure
https://scotch.io/tutorials/angularjs-best-practices-directory-structure
https://github.com/toddmotto/angular-styleguide
http://blog.thoughtram.io/angular/2015/07/07/service-vs-factory-once-and-for-all.html
https://toddmotto.com/angular-1-5-lifecycle-hooks
https://toddmotto.com/resolve-promises-in-angular-routes/
http://thoughtram.io/angular-master-class.html
http://stackoverflow.com/questions/18287482/angularjs-1-2-injectormodulerr
http://stackoverflow.com/questions/21045416/angular-js-uncaught-error-injectormodulerr
https://github.com/viewplatgh/docker-trac
https://www.digitalocean.com/community/tutorials/how-to-set-up-a-private-docker-registry-on-ubuntu-14-04
http://146.185.183.11:9000/wiki
https://www.youtube.com/watch?v=9IBljKq4XrQ

http://trochette.github.io/Angular-Design-Patterns-Best-Practices/#/intro
https://github.com/johnpapa/angular-styleguide/blob/master/a1/README.md
http://twofuckingdevelopers.com/2014/06/angularjs-best-practices-001-constants/
https://scotch.io/tutorials/internationalization-of-angularjs-applications
http://tokkobroker.com/api/playground#!/properties/property-detail_get_2
https://scotch.io/tutorials/easy-angularjs-forms-with-angular-formly
https://www.shortcutfoo.com/app/dojos/cloud9-win/cheatsheet
https://ngmap.github.io/
https://wpdevkvk.wordpress.com/2014/12/26/quickly-add-google-maps-into-your-angular-js-app/
marilynpi:~/workspace $ npm install --save angular-google-maps

https://www.npmjs.com/package/angular-google-maps
angular-google-maps@2.3.4 node_modules/angular-google-maps
├── google-maps-utility-library-v3-markerwithlabel@1.1.10
├── js-rich-marker@1.0.0
├── angular@1.5.8
├── markerclustererplus@2.1.4
├── google-maps-utility-library-v3-infobox@1.1.14 (coffee-script@1.10.0)
├── google-maps-utility-library-v3-keydragzoom@2.0.9 (coffee-script@1.10.0)
├── angular-simple-logger@0.1.7 (debug@2.2.0)
└── lodash@4.15.0
marilynpi:~/workspace $ 


https://ngmap.github.io/
https://drive.google.com/drive/folders/0B4NvAzA2_N7cWGZNaEhNSFpINVE
http://vitalets.github.io/checklist-model/

https://console.developers.google.com/apis/credentials/key/0?project=prefab-groove-141519
http://stackoverflow.com/questions/13047923/working-with-select-using-angulars-ng-options
http://www.metaltoad.com/blog/angularjs-adding-user-friendly-ng-options-default
https://google.github.io/styleguide/jsoncstyleguide.xml
http://ngmodules.org/modules/ngAutocomplete
https://github.com/login?return_to=%2FJustGoscha%2Fallmighty-autocomplete
https://ghiden.github.io/angucomplete-alt/
ésta -> http://www.justgoscha.com/allmighty-autocomplete/
http://www.infragistics.com/community/blogs/dhananjay_kumar/archive/2015/11/24/how-to-create-custom-filters-in-angularjs.aspx
https://www.npmjs.com/package/angu-complete
https://scotch.io/tutorials/building-custom-angularjs-filters
http://stackoverflow.com/questions/28036696/the-request-was-redirected-to-https-com-site-login-which-is-disallowed-f

Ctrl+Shift+B -> Best code indentation.
https://github.com/a8m/angular-filter#filterby
http://stackoverflow.com/questions/13216115/filtering-by-multiple-specific-model-properties-in-angularjs-in-or-relationship
http://plnkr.co/edit/A2IG03FLYnEYMpZ5RxEm?p=preview
http://stackoverflow.com/questions/20977703/filter-multiple-fields-using-single-input-in-angularjs
http://stackoverflow.com/questions/22247294/how-do-i-get-the-back-button-to-work-with-an-angularjs-ui-router-state-machine
http://stackoverflow.com/questions/30876130/hiding-parent-state-view-from-child-state-view-in-angularjs-best-practices
http://stackoverflow.com/questions/16635381/angular-ui-router-get-previous-state
http://stackoverflow.com/questions/32603370/ui-router-child-states-view-not-showing
https://github.com/angular-ui/ui-router/wiki/Nested-States-and-Nested-Views
https://www.smashingmagazine.com/2012/11/writing-fast-memory-efficient-javascript/
https://premium.wpmudev.org/blog/how-to-quickly-rename-a-wordpress-post-format/?utm_expid=3606929-84.YoGL0StOSa-tkbGo-lVlvw.0&utm_referrer=https%3A%2F%2Fwww.google.com.ar%2F



