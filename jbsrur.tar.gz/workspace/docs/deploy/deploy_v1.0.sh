#!/bin/bash

source .env 

# Levantar BD
sudo docker run --name wpdb -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=wp -d mysql:5.7

sudo chmod -R 777 jbsrur
cd jbsrur

# Construir docker WP+Angular
docker build -t wp-angular .

# Ejecutar la imagen.
docker run -e WORDPRESS_DB_PASSWORD=root -d -p 127.0.0.2:8080:80 -v "$PWD"/wp-content:/var/www/html/wp-content -t -i --name wp-angular --link wpdb:mysql  wp-angular

# Carga inicial BD.
docker exec -i wpdb mysql -uroot -proot wp < db.sql